% Initialize parameters
baseFileName = 'mean_square_errors_';
fileExtension = '.csv';
increment = 245;
startValue = 0;
numFiles = 93; % Adjust this to the number of files you have

% Initialize cell array to hold matrices
matrices = cell(1, numFiles);

% Loop through the file indices
for k = 1:numFiles
    % Generate the file name
    fileName = [baseFileName, num2str(startValue + (k-1) * increment), fileExtension];
    
    % Check if file exists
    if isfile(fileName)
        % Read the CSV file into a matrix
        matrices{k} = csvread(fileName);
    else
        warning(['File ', fileName, ' does not exist.']);
        matrices{k} = []; % Store an empty matrix if the file does not exist
    end
end

% Optionally, convert the cell array to a 3D matrix if all matrices have the same dimensions
if all(cellfun(@(x) isequal(size(x), size(matrices{1})), matrices))
    matrices = cat(3, matrices{:});
end

% Display the content of the cell array of matrices
%disp(matrices);

%%
error=zeros(1,numFiles);
for k=1:numFiles
    error(k) = sum(matrices{k}(:));
end
error=(error./(5120*16)).^(1/2);
%%
figure;
numBins = 93; 
% Create a histogram with 100 bins (default vertical orientation)
% Calculate the histogram counts and bin edges
[counts, edges] = histcounts(error, numBins);

% Normalize the counts to percentage
totalCounts = sum(counts);
countsPercent = (counts / totalCounts) * 100;

% Calculate the bin centers for plotting
binCenters = edges(1:end-1) + diff(edges) / 2;
% Convert the hex color code to an RGB triplet
ColorRGB1 = [39,93,242]./255;
% Convert the hex color code to an RGB triplet
edgeColorRGB2 = [40,41,42]./255;
% Plot the normalized histogram as a bar graph
barHandle=bar(binCenters, countsPercent, 'hist');      % Convert to percentage
barHandle.FaceColor = ColorRGB1;          % Change the color of the bars
barHandle.EdgeColor = edgeColorRGB2;
% Set the title and axis labels
%%title('Distribution of error with the ICA matrix');
xlabel('Error (%)');  % Labels the x-axis, representing the data values
ylabel('Frequency (%)');  % Labels the y-axis, representing the frequency of data values

dataMin = min(error);
dataMax = max(error);
error_std = std(error);
mean_error=mean(error)
disp(['Standard Deviation: ', num2str(error_std)]);
% Set the x-axis limits to span from min to max data values
xlim([dataMin dataMax]);
% Set the x-axis to logarithmic scale
%set(gca, 'XScale', 'log');

% Find the value with the maximum frequency
[maxCount, maxIdx] = max(countsPercent);
maxFreqValue = binCenters(maxIdx);  % Bin center
disp(['Value with maximum frequency: ', num2str(maxFreqValue)]);
disp(['Maximum frequency: ', num2str(maxCount)]);

cvError = error_std / mean_error;
disp(['Coefficient of Variation: ', num2str(cvError)]);
% Optional: Enhance the appearance
set(gca, 'FontSize', 12);  % Set font size of axis labels
grid on;  % Turn on the grid for better readability